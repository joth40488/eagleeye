#!/bin/bash
# KARNEL Receiver Server - Quick Start
# Usage: ./start.sh [port]

PORT="${1:-8080}"

echo "================================================"
echo "  KARNEL RECEIVER SERVER"
echo "================================================"
echo ""

# Install dependencies
pip3 install flask flask-cors -q 2>/dev/null

# Start server
export KARNEL_PORT="$PORT"
echo "[*] Starting server on port $PORT..."
echo "[*] Dashboard: http://0.0.0.0:$PORT"
echo "[*] Press Ctrl+C to stop"
echo ""

python3 "$(dirname "$0")/server.py"
